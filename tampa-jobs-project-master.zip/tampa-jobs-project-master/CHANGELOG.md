# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [0.0.0]

* Additions...
    * Created an earlier version of this template, which was sparsely populated

## [0.0.1]

* Additions
    * Major update to template, new sections added
    * Template now contains (or will soon contain) basic instructions, not only for the entire project but also for each individual section
    * Project can now be completed by removing indicated text and replacing with your own content.
    * Citation file added to repo
