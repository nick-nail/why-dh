# TODO

## General or Current TODO Items

* Leader (starting)
    * Fork this repository
    * Invite your groupmates to collaborate
    * Edit mkdocs.yml to reflect your pages and information
    * Edit LICENSE and CITATION.cff to reflect your information
    * Add general introduction to BOTH README.md and docs/index.md
* Everyone
    * Make sure you are on your **OWN** branch, create one if not
    * If you have not already, open a pull request to the master branch
    * Edit your pages on GitHub and commit to your own branch
    * Add any images needed into docs/files
    * Double-check that everything looks right on GitHub
    * Inform your group leader that the pull request is ready
* Leader (finishing)
    * Review and accept pull requests of group members
    * Double-check that everything looks right on GitHub
    * (optional) Upload your repo to readthedocs.io
